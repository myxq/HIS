create
    definer = root@localhost procedure 患者退费(IN 处方ID_d int(5), IN 发票号_d int(10), IN 操作员ID_d int(5), OUT 操作 varchar(55))
BEGIN
 DECLARE l_挂号ID INT DEFAULT 0;
 DECLARE l_缴费ID INT DEFAULT 0;
 DECLARE l_发票号 INT DEFAULT 0;
 DECLARE l_当前时间 datetime DEFAULT '2019-7-15 23:59:59';
 
 DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;

	START TRANSACTION;
 
 UPDATE prescription SET `处方状态` = 4 WHERE `处方ID` = 处方ID_d;
 
 SET l_挂号ID = (SELECT `挂号ID` FROM prescription WHERE `处方ID` = 处方ID_d);

	SET l_缴费ID = (SELECT `缴费ID` FROM regist_pay WHERE `挂号ID` = l_挂号ID);
	
 SET l_发票号 = (SELECT IFNULL(MAX(`发票号码`),0)+1 FROM invoice);
 
 SET l_当前时间 = NOW();
 
 UPDATE pat_regist SET `挂号状态` = 4 WHERE `挂号ID` = l_挂号ID;
 
 UPDATE pay_detail SET `退费药品价格` = -ABS(`退费药品价格`),`缴费状态` = 3  WHERE `缴费ID` = l_缴费ID;
 
 UPDATE invoice SET `冲红发票号码` = l_发票号 WHERE `发票号码` = 发票号_d;
 
 UPDATE prescription SET `处方状态` = 4 WHERE `处方ID` = 处方ID_d;
 
 INSERT INTO invoice VALUES(l_发票号,NULL,1,l_当前时间,操作员ID_d,51,NULL,1,1);

IF t_error = 1 THEN
		ROLLBACK;
		SET 操作 = '操作失败';
	ELSE
		COMMIT;
		SET 操作 = '操作成功';
	END IF;

END;

