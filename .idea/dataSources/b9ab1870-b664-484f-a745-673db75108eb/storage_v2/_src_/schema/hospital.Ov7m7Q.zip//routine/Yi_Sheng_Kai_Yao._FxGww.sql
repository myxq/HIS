create
    definer = root@localhost procedure 医生开药(IN 挂号ID_d int(5), IN 处方名称_d varchar(255), IN 药品列表_d varchar(225),
                                            OUT 操作 varchar(55))
BEGIN
	DECLARE l_处方ID INT DEFAULT 0;
	DECLARE l_开立医生ID INT DEFAULT 0;
	DECLARE l_开立时间 datetime DEFAULT '2019-7-15 23:59:59';
	DECLARE l_药品列表 VARCHAR(225) DEFAULT '';
	
	DECLARE l_药品ID INT DEFAULT 0;
	DECLARE l_药品数量 INT DEFAULT 0;
	DECLARE l_用法 VARCHAR(225) DEFAULT '';
	DECLARE l_用量 VARCHAR(225) DEFAULT '';
	DECLARE l_频次 VARCHAR(225) DEFAULT '';
	DECLARE l_药品单价 DECIMAL(10,2) DEFAULT 0.00;
	

	DECLARE l_原长度 INT DEFAULT 0;
	DECLARE l_现长度 INT DEFAULT 0;
	DECLARE l_逗号分隔符 INT DEFAULT 0;
	DECLARE l_下划线分隔符 INT DEFAULT 0;
	DECLARE l_循环变量 INT DEFAULT 0;
	DECLARE l_临时列表 VARCHAR(225) DEFAULT '';
	DECLARE l_划价ID INT DEFAULT 0;
	DECLARE l_缴费ID INT DEFAULT 0;
	
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;

	START TRANSACTION;
	
	
	SET l_处方ID = (SELECT IFNULL(MAX(`处方ID`),0)+1 FROM prescription);
	SET l_开立医生ID = (SELECT `看诊医生ID` FROM regist WHERE `挂号编号` = 挂号ID_d);
	SET l_开立时间 = NOW();
	
	SET l_药品列表 = REPLACE(药品列表_d,',','');
	SET l_原长度 = LENGTH(药品列表_d);
	SET l_现长度 = LENGTH(l_药品列表);
	SET l_循环变量 = l_原长度 - l_现长度;
	SET l_划价ID = (SELECT IFNULL(MAX(`划价ID`),0)+1 FROM fee_detail);
	SET l_缴费ID = (SELECT IFNULL(MAX(`缴费ID`),0)+1 FROM regist_pay);
	
	
	INSERT INTO prescription VALUES(挂号ID_d,l_处方ID,处方名称_d,l_开立医生ID,l_开立时间,1,1);
	
	# 药品列表中以‘药品ID_药品数量_用法_用量_频次,药品ID_药品数量_用法_用量_频次,药品ID_药品数量_用法_用量_频次’的形式传入
	WHILE l_循环变量 >= 0 DO
		SET l_临时列表 = SUBSTRING_INDEX(药品列表_d,',',-1);	
		
		SET l_药品ID = SUBSTRING_INDEX(l_临时列表,'_',1);
		SET l_药品数量 = SUBSTRING_INDEX(SUBSTRING_INDEX(l_临时列表,'_',2),'_',-1);
		SET l_用法 = SUBSTRING_INDEX(SUBSTRING_INDEX(l_临时列表,'_',3),'_',-1);
		SET l_用量 = SUBSTRING_INDEX(SUBSTRING_INDEX(l_临时列表,'_',4),'_',-1);
		SET l_频次 = SUBSTRING_INDEX(l_临时列表,'_',-1);
		
		SET l_药品单价 = (SELECT `药品单价` FROM drugs WHERE `药品ID` = l_药品ID);			
		
		SET 药品列表_d = SUBSTRING_INDEX(药品列表_d,',',l_循环变量);
		SET l_循环变量 = l_循环变量 - 1;
		
		INSERT INTO prescription_detail VALUES(l_处方ID,l_药品ID,l_药品数量,l_用法,l_用量,l_频次,1,1);
				
		INSERT INTO fee_detail VALUES(l_划价ID,l_药品ID,NULL,l_药品单价,l_药品数量,1,1);
		INSERT INTO pay_detail VALUES(l_缴费ID,l_药品ID,l_药品单价,l_药品单价,l_药品数量,1,1);
			
	END WHILE;
	INSERT INTO regist_fee_detail VALUES(挂号ID_d,l_划价ID,1);
	INSERT INTO regist_pay VALUES(挂号ID_d,l_缴费ID,1);
	
	IF t_error = 1 THEN
		ROLLBACK;
		SET 操作 = '操作失败';
	ELSE
		COMMIT;
		SET 操作 = '操作成功';
	END IF;		
END;

