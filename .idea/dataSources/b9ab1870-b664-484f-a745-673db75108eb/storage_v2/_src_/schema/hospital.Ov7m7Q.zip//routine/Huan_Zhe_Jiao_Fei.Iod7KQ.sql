create
    definer = root@localhost procedure 患者缴费(IN 处方ID_d int(5), IN 操作员ID_d int(5), OUT 操作 varchar(55))
BEGIN
	DECLARE l_挂号ID INT DEFAULT 0;
	DECLARE l_发票号 INT DEFAULT 0;
	DECLARE l_缴费ID INT DEFAULT 0;
	DECLARE l_缴费总额 DECIMAL(11,2) DEFAULT 0.00;
	DECLARE l_缴费时间 datetime DEFAULT '2019-7-15 23:59:59';
	
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;

	START TRANSACTION;	
	
	SET l_缴费时间 = NOW();
	
	SET l_挂号ID = (SELECT `挂号ID` FROM prescription WHERE `处方ID` = 处方ID_d);

	SET l_缴费ID = (SELECT `缴费ID` FROM regist_pay WHERE `挂号ID` = l_挂号ID);
		
	SET l_发票号 = (SELECT IFNULL(MAX(`发票号码`),0)+1 FROM invoice);
	
	SET l_缴费总额 = (SELECT SUM(`药品价格` * `药品数量`) FROM pay_detail WHERE `缴费ID` = l_缴费ID);
	
	INSERT INTO invoice VALUES(l_发票号,l_缴费总额,1,l_缴费时间,操作员ID_d,51,NULL,0,1);
	
	UPDATE regist SET `发票号` = l_发票号 WHERE `挂号编号` =l_挂号ID;
	
	UPDATE pay_detail SET `缴费状态` = 2 WHERE `缴费ID` = l_缴费ID;
	
	UPDATE prescription SET `处方状态` = 2 WHERE `处方ID` = 处方ID_d;
	
	UPDATE pat_regist SET `挂号状态` = 3 WHERE `挂号ID` = l_挂号ID;

	IF t_error = 1 THEN
		ROLLBACK;
		SET 操作 = '操作失败';
	ELSE
		COMMIT;
		SET 操作 = '操作成功';
	END IF;		
END;

