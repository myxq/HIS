create
    definer = root@localhost procedure 药房发药(IN 病历ID_d int, OUT 操作 varchar(55))
BEGIN
	DECLARE l_身份证号 VARCHAR(55) DEFAULT '';
	DECLARE l_挂号ID INT DEFAULT 0;
	DECLARE l_处方ID INT DEFAULT 0;
	
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;

	START TRANSACTION;
	
	SET l_身份证号 = (SELECT `身份证号` FROM patient WHERE `病历号` = 病历ID_d);
	
	SET l_挂号ID = (SELECT `挂号ID` FROM pat_regist WHERE `身份证号` = l_身份证号 AND `挂号状态` = 3);
	
	SET l_处方ID = (SELECT `处方ID` FROM prescription WHERE `挂号ID` = l_挂号ID);
	
	UPDATE prescription SET `处方状态` = 3 WHERE `处方ID` = l_处方ID;
	
	UPDATE prescription_detail SET `状态` = 2 WHERE `处方ID` = l_处方ID;
		
IF t_error = 1 THEN
		ROLLBACK;
		SET 操作 = '操作失败';
	ELSE
		COMMIT;
		SET 操作 = '操作成功';
	END IF;	
END;

