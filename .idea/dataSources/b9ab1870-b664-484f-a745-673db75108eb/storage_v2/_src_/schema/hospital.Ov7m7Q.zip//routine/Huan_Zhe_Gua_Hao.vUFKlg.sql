create
    definer = root@localhost procedure 患者挂号(IN 身份证号_d varchar(55), IN 患者姓名_d varchar(10), IN 性别_d varchar(10),
                                            IN 出生日期_d date, IN 年龄_d int(3), IN 年龄类型_d varchar(5),
                                            IN 家庭住址_d varchar(255), IN 午别_d varchar(25), IN 挂号科室_d int(5),
                                            IN 看诊医生ID_d int(5), IN 挂号级别_d int(5), IN 结算类别_d tinyint(1),
                                            IN 是否要病历本_d tinyint(1), IN 挂号员ID_d int(5), OUT 操作 varchar(55))
BEGIN	
	DECLARE l_病历ID INT DEFAULT 0;
	DECLARE l_挂号时间 datetime DEFAULT '2019-7-15 23:59:59';
	DECLARE l_看诊日期 date DEFAULT '2019-7-15';
	DECLARE l_身份证号 VARCHAR(55) DEFAULT '';
	DECLARE l_病历号 INT DEFAULT 0;
	DECLARE l_当前医生已挂号人数 INT DEFAULT 0;
	DECLARE l_挂号限额 INT DEFAULT 0;
	DECLARE l_挂号ID INT DEFAULT 0;
	
-- 	DECLARE t_error INTEGER DEFAULT 0;
-- 	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
-- 
-- 	START TRANSACTION;
		
	
		SET l_挂号限额 = (SELECT `挂号限额` FROM regist_rank WHERE `ID主码` = 挂号级别_d);
		SET l_当前医生已挂号人数 = (SELECT COUNT(*) FROM regist WHERE `看诊医生ID` = 看诊医生ID_d);
	
		IF l_挂号限额 >= l_当前医生已挂号人数 THEN
			SET l_挂号ID = (SELECT IFNULL(MAX(`挂号编号`),0)+1 FROM regist);
			SET l_挂号时间 = NOW();
			SET l_看诊日期 = NOW();
			SET l_身份证号 = (SELECT DISTINCT `身份证号` FROM patient WHERE `身份证号` = 身份证号_d);
	
			IF l_身份证号 IS NULL THEN
				SET l_病历号 = (SELECT IFNULL( MAX(`病历号`),0)+1 FROM medi_record);
				IF l_病历号 = 1 THEN
					UPDATE medi_record SET `病历号` = 1 WHERE `病历号` = 0;
				ELSE
					INSERT INTO medi_record VALUES(l_病历号,NULL,NULL,NULL,NULL,NULL,NULL,1,1);
				END IF;
			
				INSERT INTO patient VALUES(患者姓名_d,性别_d,年龄_d,年龄类型_d,出生日期_d,身份证号_d,家庭住址_d,l_病历号);

				SET 操作 = '新建病历，挂号成功';
			ELSE

				SET 操作 = '已存在病历，挂号成功';
			END IF;
		
			INSERT INTO regist VALUES(l_挂号ID,看诊医生ID_d,是否要病历本_d,NULL,l_挂号时间,1,结算类别_d,挂号员ID_d,1);

			INSERT INTO pat_regist VALUES(身份证号_d,l_挂号ID,1,1);
		ELSE
			SET 操作 = '当前医生挂号额度已满,挂号失败';
		END IF;
	
-- IF t_error = 1 THEN
-- 		ROLLBACK;
-- 		SET 操作 = '操作失败';
-- 	ELSE
-- 		COMMIT;
-- 	END IF;										
END;

