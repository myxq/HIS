create
    definer = root@localhost procedure 医生看诊(IN 挂号ID_d int(5), IN 诊断信息_d varchar(225), OUT 操作 varchar(225))
BEGIN
	DECLARE l_病历ID INT DEFAULT 0;
	DECLARE l_身份证号 VARCHAR(55) DEFAULT '';
	DECLARE l_挂号ID INT DEFAULT 0;
	
-- 	DECLARE t_error INTEGER DEFAULT 0;
-- 	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
-- 	
-- 	START TRANSACTION;
		
	SET  l_挂号ID = (SELECT `挂号ID` FROM pat_regist WHERE `挂号ID` = 挂号ID_d);
	IF l_挂号ID is NULL THEN 
		SET 操作 = '挂号ID不存在，操作失败';
	ELSE
		SET l_身份证号 = (SELECT DISTINCT `身份证号` FROM pat_regist WHERE `挂号ID` = 挂号ID_d);
		SET l_病历ID = (SELECT DISTINCT `病历号` FROM patient WHERE `身份证号` = l_身份证号);
		UPDATE medi_record SET `主诉` = 诊断信息_d,`病历记录号` = 1 WHERE `病历号` = l_病历ID;
		UPDATE regist SET `看诊状态` = 2 WHERE `挂号编号` = 挂号ID_d;
		UPDATE pat_regist SET `挂号状态` = 2 WHERE `挂号ID` = 挂号ID_d;
		SET 操作 = '操作成功';
	END IF;
	
-- 	IF t_error = 1 THEN
-- 		ROLLBACK;
-- 		SET 操作 = '操作失败';
-- 	ELSE
-- 		COMMIT;
-- 	END IF;	
END;

