create
    definer = root@localhost procedure 退号(IN 挂号ID_d int(5), OUT 操作 varchar(55))
BEGIN
	#Routine body goes here...
	DECLARE l_挂号状态 INT DEFAULT 0;
	DECLARE l_就诊状态 INT DEFAULT 0;
	
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;

	START TRANSACTION;
	
	SET l_挂号状态 = (SELECT `挂号状态` FROM pat_regist WHERE `挂号ID` = 挂号ID_d);
	
	IF l_挂号状态 = 1 THEN
	
		UPDATE regist SET `看诊状态` = 3 WHERE `挂号编号` = 挂号ID_d;
		
		UPDATE pat_regist SET `挂号状态` = 5 WHERE `挂号ID` = 挂号ID_d;	
		
		SET 操作 = '操作成功';
		
	ELSE
		
		SET 操作 = '操作失败';
		
	END IF;
	
	IF t_error = 1 THEN
		ROLLBACK;
		SET 操作 = '操作失败';
	ELSE
		COMMIT;
	END IF;		
END;

